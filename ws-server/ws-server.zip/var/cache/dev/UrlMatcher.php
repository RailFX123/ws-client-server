<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/movies' => [
            [['_route' => 'app_peliculas_index', '_controller' => 'App\\Controller\\PeliculasController::index'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'app_peliculas_create', '_controller' => 'App\\Controller\\PeliculasController::create'], null, ['POST' => 0], null, false, false, null],
        ],
        '/update' => [[['_route' => 'app_peliculas_update', '_controller' => 'App\\Controller\\PeliculasController::update'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/movies/([^/]++)/(?'
                    .'|changeurl/([^/]++)(*:45)'
                    .'|delete(*:58)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        45 => [[['_route' => 'app_peliculas_changeurl', '_controller' => 'App\\Controller\\PeliculasController::changeurl'], ['id', 'newurl'], ['GET' => 0], null, true, true, null]],
        58 => [
            [['_route' => 'app_peliculas_deleteestreno', '_controller' => 'App\\Controller\\PeliculasController::deleteEstreno'], ['id'], ['GET' => 0], null, false, false, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
